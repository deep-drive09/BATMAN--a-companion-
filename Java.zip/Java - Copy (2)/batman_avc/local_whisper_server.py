import os
from flask import Flask, request, jsonify
from faster_whisper import WhisperModel

app = Flask(__name__)

print("Loading Whisper model into RAM... (this takes a moment)")
# Upgraded to small.en for much higher accuracy ("perfect" transcription)
model_size = "small.en"
# Run on CPU with int8. If you have an NVIDIA GPU, change device to "cuda" and compute_type to "float16".
model = WhisperModel(model_size, device="cpu", compute_type="int8")
print("Model loaded! Listening on http://127.0.0.1:5000")

@app.route('/transcribe', methods=['POST'])
def transcribe():
    if 'file' not in request.files:
        return jsonify({'error': 'No file part'}), 400
    
    file = request.files['file']
    filepath = "temp_recording.wav"
    file.save(filepath)

    try:
        segments, info = model.transcribe(filepath, beam_size=5)
        text = " ".join([segment.text for segment in segments])
        
        # Cleanup
        if os.path.exists(filepath):
            os.remove(filepath)
            
        return jsonify({'text': text.strip()})
    except Exception as e:
        return jsonify({'error': str(e)}), 500



import g4f
from g4f.client import Client

# Initialize fast client once
client = Client()

@app.route('/chat', methods=['POST'])
def chat():
    data = request.json
    user_msg = data.get("message", "")
    if not user_msg:
        return jsonify({"error": "No message"}), 400
    
    try:
        # Prompting for a fast, brooding Batman response
        system_prompt = "You are Batman. Be extremely brooding, concise, and stay completely in character. Never break character. Only reply in 1 or 2 short sentences."
        
        response = client.chat.completions.create(
            model="gpt-4o-mini",
            messages=[
                {"role": "system", "content": system_prompt},
                {"role": "user", "content": user_msg}
            ]
        )
        ans = response.choices[0].message.content
        return jsonify({"response": ans.strip()})
    except Exception as e:
        return jsonify({"error": str(e)}), 500

import asyncio
import edge_tts
from playsound import playsound
import tempfile
import threading

@app.route('/tts', methods=['POST'])
def tts():
    data = request.json
    text = data.get("text", "")
    if not text:
        return jsonify({"error": "No text"}), 400
    
    def generate_and_play():
        try:
            # en-US-ChristopherNeural is a deep, excellent male voice
            communicate = edge_tts.Communicate(text, "en-US-ChristopherNeural", rate="-10%")
            # Save to a temporary file
            temp_file = tempfile.NamedTemporaryFile(delete=False, suffix=".mp3")
            temp_file.close()
            
            asyncio.run(communicate.save(temp_file.name))
            # Play it locally on the server (which is the user's computer)
            playsound(temp_file.name)
            
            # Clean up
            os.remove(temp_file.name)
        except Exception as e:
            print("TTS Error:", e)

    # Run in background so it doesn't block the Flask response
    threading.Thread(target=generate_and_play).start()
    return jsonify({"status": "playing"})

if __name__ == '__main__':
    # Disable werkzeug logging for cleaner terminal output
    import logging
    log = logging.getLogger('werkzeug')
    log.setLevel(logging.ERROR)
    app.run(port=5000)
