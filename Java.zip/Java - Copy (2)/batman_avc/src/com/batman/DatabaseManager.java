package com.batman;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;

/**
 * Handles all SQLite database connectivity, creation, and persistence.
 */
public class DatabaseManager {
    private static final String DB_URL = "jdbc:sqlite:batman_stats.db";

    public DatabaseManager() {
        initDatabase();
    }

    private void initDatabase() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             Statement stmt = conn.createStatement()) {
            
            // Create the stats table if it doesn't exist
            String sql = "CREATE TABLE IF NOT EXISTS stats (" +
                         "id INTEGER PRIMARY KEY, " +
                         "stamina INTEGER, " +
                         "batarang_ammo INTEGER, " +
                         "threat_level INTEGER)";
            stmt.execute(sql);
            
            // Insert a default row if the table is empty
            ResultSet rs = stmt.executeQuery("SELECT count(*) FROM stats WHERE id = 1");
            if (rs.next() && rs.getInt(1) == 0) {
                String insert = "INSERT INTO stats (id, stamina, batarang_ammo, threat_level) VALUES (1, 100, 100, 0)";
                stmt.execute(insert);
            }
        } catch (Exception e) {
            System.err.println("Database Initialization Error: " + e.getMessage());
        }
    }

    public HeroStats loadStats() {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement("SELECT stamina, batarang_ammo, threat_level FROM stats WHERE id = 1")) {
            
            ResultSet rs = pstmt.executeQuery();
            if (rs.next()) {
                return new HeroStats(
                    rs.getInt("stamina"),
                    rs.getInt("batarang_ammo"),
                    rs.getInt("threat_level")
                );
            }
        } catch (Exception e) {
            System.err.println("Database Load Error: " + e.getMessage());
        }
        // Fallback defaults if load fails
        return new HeroStats(100, 100, 0);
    }

    public void saveStats(HeroStats stats) {
        try (Connection conn = DriverManager.getConnection(DB_URL);
             PreparedStatement pstmt = conn.prepareStatement(
                 "UPDATE stats SET stamina = ?, batarang_ammo = ?, threat_level = ? WHERE id = 1")) {
            
            pstmt.setInt(1, stats.getStamina());
            pstmt.setInt(2, stats.getBatarangAmmo());
            pstmt.setInt(3, stats.getCityThreatLevel());
            pstmt.executeUpdate();
            
        } catch (Exception e) {
            System.err.println("Database Save Error: " + e.getMessage());
        }
    }
}
