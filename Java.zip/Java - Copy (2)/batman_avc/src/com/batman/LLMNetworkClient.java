package com.batman;

import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.nio.charset.StandardCharsets;

public class LLMNetworkClient {
    public String askBatman(String userMessage, HeroStats stats) {
        try {
            URL url = java.net.URI.create("http://127.0.0.1:5000/chat").toURL();
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("POST");
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setDoOutput(true);

            String escapedMessage = userMessage.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
            String jsonPayload = "{\"message\": \"" + escapedMessage + "\"}";

            try (OutputStream os = conn.getOutputStream()) {
                byte[] input = jsonPayload.getBytes(StandardCharsets.UTF_8);
                os.write(input, 0, input.length);
            }

            if (conn.getResponseCode() == 200) {
                try (BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream(), StandardCharsets.UTF_8))) {
                    StringBuilder response = new StringBuilder();
                    String responseLine;
                    while ((responseLine = br.readLine()) != null) {
                        response.append(responseLine.trim());
                    }
                    
                    String resStr = response.toString();
                    if (resStr.contains("\"response\":")) {
                        // Extracting text between the quotes
                        int startQuote = resStr.indexOf("\"", resStr.indexOf("\"response\":") + 11) + 1;
                        int endQuote = resStr.lastIndexOf("\"");
                        if (startQuote > 0 && endQuote > startQuote) {
                            String ans = resStr.substring(startQuote, endQuote);
                            ans = ans.replace("\\n", "\n").replace("\\\"", "\"");
                            return decodeUnicode(ans);
                        }
                    }
                    return "Comm link established, but analysis failed.";
                }
            } else {
                return "Error connecting to Batcomputer (Status " + conn.getResponseCode() + ")";
            }
        } catch (Exception e) {
            e.printStackTrace();
            return "Batcomputer offline. Make sure the Python server is running.";
        }
    }

    private String decodeUnicode(String st) {
        StringBuilder sb = new StringBuilder(st.length());
        for (int i = 0; i < st.length(); i++) {
            char ch = st.charAt(i);
            if (ch == '\\' && i + 5 < st.length() && st.charAt(i + 1) == 'u') {
                try {
                    sb.append((char) Integer.parseInt(st.substring(i + 2, i + 6), 16));
                    i += 5;
                } catch (NumberFormatException e) {
                    sb.append(ch);
                }
            } else {
                sb.append(ch);
            }
        }
        return sb.toString();
    }
}
