package com.batman;

public class HeroStats {
    private int stamina;
    private int batarangAmmo;
    private int cityThreatLevel;

    public HeroStats() {
        this.stamina = 100;
        this.batarangAmmo = 100;
        this.cityThreatLevel = 0;
    }

    public HeroStats(int stamina, int batarangAmmo, int cityThreatLevel) {
        this.stamina = stamina;
        this.batarangAmmo = batarangAmmo;
        this.cityThreatLevel = cityThreatLevel;
    }

    public int getStamina() { return stamina; }
    public void setStamina(int stamina) { this.stamina = Math.max(0, Math.min(100, stamina)); }
    public void addStamina(int amount) { setStamina(this.stamina + amount); }

    public int getBatarangAmmo() { return batarangAmmo; }
    public void setBatarangAmmo(int ammo) { this.batarangAmmo = Math.max(0, Math.min(100, ammo)); }
    public void addBatarangAmmo(int amount) { setBatarangAmmo(this.batarangAmmo + amount); }

    public int getCityThreatLevel() { return cityThreatLevel; }
    public void setCityThreatLevel(int threat) { this.cityThreatLevel = Math.max(0, Math.min(100, threat)); }
    public void addCityThreatLevel(int amount) { setCityThreatLevel(this.cityThreatLevel + amount); }
}
