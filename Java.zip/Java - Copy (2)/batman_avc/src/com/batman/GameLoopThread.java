package com.batman;

import javax.swing.SwingUtilities;

/**
 * Background thread game loop that modifies stats over time.
 */
public class GameLoopThread extends Thread {
    private volatile boolean running = true;
    private HeroStats stats;
    private BatmanPet ui;
    private DatabaseManager dbManager;

    public GameLoopThread(HeroStats stats, BatmanPet ui, DatabaseManager dbManager) {
        this.stats = stats;
        this.ui = ui;
        this.dbManager = dbManager;
    }

    public void stopLoop() {
        running = false;
        this.interrupt();
    }

    @Override
    public void run() {
        while (running) {
            try {
                // Sleep for 60 seconds
                Thread.sleep(60000);

                // Drain stamina and increase threat level automatically
                stats.addStamina(-5);
                stats.addCityThreatLevel(5);

                // Auto-save state
                dbManager.saveStats(stats);

                // Safely update UI state on the Swing Event Dispatch Thread
                SwingUtilities.invokeLater(() -> {
                    ui.updateStatsUI();
                    
                    // Automated interactions based on stats
                    if (stats.getCityThreatLevel() >= 80 && stats.getBatarangAmmo() > 0) {
                        ui.triggerAction("patrol"); // Auto patrol if threat is very high
                    } else if (stats.getStamina() < 20) {
                        ui.triggerAction("sleep");  // Auto sleep if exhausted
                    } else {
                        // Return to idle periodically
                        ui.triggerAction("idle");
                    }
                });

            } catch (InterruptedException e) {
                // Thread was interrupted (likely shutting down), break the loop
                break;
            }
        }
    }
}
