package com.batman;

import javax.sound.sampled.*;
import java.io.*;
import java.net.HttpURLConnection;
import java.net.URL;

/**
 * Handles capturing 16kHz audio from the microphone and sending it 
 * to the Groq Whisper API (whisper-large-v3) for near-instant transcription.
 */
public class WhisperAudioRecorder {
    private static final String WHISPER_API_URL = "http://127.0.0.1:5000/transcribe";
    private TargetDataLine microphone;
    private AudioFormat format;
    private ByteArrayOutputStream outStream;
    private volatile boolean isRecording = false;

    public WhisperAudioRecorder() {
        // Required for Whisper: 16kHz, 16-bit Mono PCM WAV
        format = new AudioFormat(16000, 16, 1, true, false);
    }

    public void startRecording() {
        try {
            DataLine.Info info = new DataLine.Info(TargetDataLine.class, format);
            if (!AudioSystem.isLineSupported(info)) {
                System.err.println("Microphone not supported.");
                return;
            }
            microphone = (TargetDataLine) AudioSystem.getLine(info);
            microphone.open(format);
            microphone.start();
            
            isRecording = true;
            outStream = new ByteArrayOutputStream();
            
            // Capture audio on a background worker thread
            Thread recordThread = new Thread(() -> {
                byte[] buffer = new byte[4096];
                while (isRecording) {
                    int bytesRead = microphone.read(buffer, 0, buffer.length);
                    if (bytesRead > 0) {
                        outStream.write(buffer, 0, bytesRead);
                    }
                }
            });
            recordThread.start();
            System.out.println("Microphone recording started...");
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public String stopRecordingAndTranscribe() {
        isRecording = false;
        if (microphone != null) {
            microphone.stop();
            microphone.close();
        }
        System.out.println("Recording stopped. Converting and sending to Groq Whisper...");
        
        try {
            // Convert raw PCM bytes to properly headered WAV byte array
            byte[] rawAudio = outStream.toByteArray();
            ByteArrayInputStream bais = new ByteArrayInputStream(rawAudio);
            AudioInputStream ais = new AudioInputStream(bais, format, rawAudio.length / format.getFrameSize());
            
            ByteArrayOutputStream wavStream = new ByteArrayOutputStream();
            AudioSystem.write(ais, AudioFileFormat.Type.WAVE, wavStream);
            byte[] wavBytes = wavStream.toByteArray();
            
            return transcribeWithGroq(wavBytes);
        } catch (Exception e) {
            e.printStackTrace();
            return "";
        }
    }

    private String transcribeWithGroq(byte[] wavBytes) throws Exception {
        String boundary = "Boundary" + System.currentTimeMillis();
        URL url = java.net.URI.create(WHISPER_API_URL).toURL();
        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
        conn.setRequestMethod("POST");
        conn.setRequestProperty("Content-Type", "multipart/form-data; boundary=" + boundary);
        conn.setDoOutput(true);

        // Build the multipart form-data payload
        try (DataOutputStream os = new DataOutputStream(conn.getOutputStream())) {
            // Field: model
            os.writeBytes("--" + boundary + "\r\n");
            os.writeBytes("Content-Disposition: form-data; name=\"model\"\r\n\r\n");
            os.writeBytes("whisper-large-v3\r\n");

            // Field: file
            os.writeBytes("--" + boundary + "\r\n");
            os.writeBytes("Content-Disposition: form-data; name=\"file\"; filename=\"recording.wav\"\r\n");
            os.writeBytes("Content-Type: audio/wav\r\n\r\n");
            os.write(wavBytes);
            os.writeBytes("\r\n");
            
            os.writeBytes("--" + boundary + "--\r\n");
            os.flush();
        }

        // Handle Response
        if (conn.getResponseCode() == 200) {
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            StringBuilder sb = new StringBuilder();
            String line;
            while ((line = br.readLine()) != null) {
                sb.append(line);
            }
            
            // Extract the "text" field from the JSON response
            String json = sb.toString();
            String targetKey = "\"text\":\"";
            int idx = json.indexOf(targetKey);
            if (idx == -1) {
                targetKey = "\"text\": \"";
                idx = json.indexOf(targetKey);
            }
            if (idx != -1) {
                idx += targetKey.length();
                int endIdx = json.indexOf("\"", idx);
                while (endIdx != -1 && json.charAt(endIdx-1) == '\\') {
                    endIdx = json.indexOf("\"", endIdx+1);
                }
                if (endIdx != -1) {
                    return json.substring(idx, endIdx).replace("\\n", " ").replace("\\\"", "\"").trim();
                }
            }
            return json; // Fallback
        } else {
            System.err.println("Groq API Error: " + conn.getResponseCode());
            BufferedReader br = new BufferedReader(new InputStreamReader(conn.getErrorStream()));
            String line;
            while ((line = br.readLine()) != null) System.err.println(line);
            return "";
        }
    }
}
