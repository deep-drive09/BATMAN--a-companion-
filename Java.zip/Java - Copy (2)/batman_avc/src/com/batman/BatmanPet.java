package com.batman;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;

public class BatmanPet extends JFrame {
    private HeroStats stats;
    private DatabaseManager db;
    private LLMNetworkClient llmClient;
    private GameLoopThread gameLoop;
    private WhisperAudioRecorder audioRecorder;

    private TacticalAvatarPanel avatarPanel;
    private TacticalStatsPanel statsPanel;
    private TacticalButton btnVoice;

    private int mouseX, mouseY;
    private boolean isRecording = false;

    public BatmanPet() {
        super("A.V.C. Batcomputer Terminal");

        db = new DatabaseManager();
        stats = db.loadStats();
        llmClient = new LLMNetworkClient();
        audioRecorder = new WhisperAudioRecorder();

        setUndecorated(true);
        setSize(700, 400);
        setLocationRelativeTo(null);
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        // Main Container
        JPanel contentPane = new JPanel(new BorderLayout());
        contentPane.setBackground(new Color(18, 18, 20)); // Deep charcoal
        contentPane.setBorder(BorderFactory.createLineBorder(new Color(45, 45, 50), 2));
        setContentPane(contentPane);

        // Custom Title Bar
        JPanel titleBar = new JPanel(new BorderLayout());
        titleBar.setBackground(new Color(30, 30, 35));
        titleBar.setPreferredSize(new Dimension(700, 35));
        
        JLabel titleLabel = new JLabel("  BATCOMPUTER // A.V.C. TERMINAL");
        titleLabel.setForeground(new Color(150, 150, 160));
        titleLabel.setFont(new Font("Consolas", Font.BOLD, 14));
        titleBar.add(titleLabel, BorderLayout.WEST);

        JButton closeBtn = new JButton("X");
        closeBtn.setFocusPainted(false);
        closeBtn.setBorderPainted(false);
        closeBtn.setContentAreaFilled(false);
        closeBtn.setOpaque(true);
        closeBtn.setBackground(new Color(30, 30, 35));
        closeBtn.setForeground(new Color(150, 150, 160));
        closeBtn.setFont(new Font("Arial", Font.BOLD, 14));
        closeBtn.setPreferredSize(new Dimension(45, 35));
        closeBtn.addMouseListener(new MouseAdapter() {
            public void mouseEntered(MouseEvent e) { closeBtn.setBackground(new Color(232, 17, 35)); closeBtn.setForeground(Color.WHITE); }
            public void mouseExited(MouseEvent e) { closeBtn.setBackground(new Color(30, 30, 35)); closeBtn.setForeground(new Color(150, 150, 160)); }
        });
        closeBtn.addActionListener(e -> System.exit(0));
        titleBar.add(closeBtn, BorderLayout.EAST);

        // Window Dragging Logic
        titleBar.addMouseListener(new MouseAdapter() {
            public void mousePressed(MouseEvent e) { mouseX = e.getX(); mouseY = e.getY(); }
        });
        titleBar.addMouseMotionListener(new MouseMotionAdapter() {
            public void mouseDragged(MouseEvent e) {
                setLocation(e.getXOnScreen() - mouseX, e.getYOnScreen() - mouseY);
            }
        });
        contentPane.add(titleBar, BorderLayout.NORTH);

        // Main Body Layout
        JPanel bodyPanel = new JPanel(null);
        bodyPanel.setBackground(new Color(18, 18, 20));
        contentPane.add(bodyPanel, BorderLayout.CENTER);

        // 1. Sleek Avatar Panel
        avatarPanel = new TacticalAvatarPanel();
        avatarPanel.setBounds(20, 20, 300, 320);
        bodyPanel.add(avatarPanel);

        // 2. Modern Stats Progress Bars
        statsPanel = new TacticalStatsPanel();
        statsPanel.setBounds(340, 20, 330, 180);
        bodyPanel.add(statsPanel);

        // 3. Clearly Labeled Professional Buttons
        JPanel buttonPanel = new JPanel(new GridLayout(3, 2, 10, 10));
        buttonPanel.setBackground(new Color(18, 18, 20));
        buttonPanel.setBounds(340, 215, 330, 125);

        btnVoice = new TacticalButton("\uD83C\uDF99\uFE0F TALK"); 
        btnVoice.setForeground(new Color(241, 196, 15)); // Batman Yellow Accent
        
        TacticalButton btnPatrol = new TacticalButton("\uD83D\uDCFA PATROL");
        TacticalButton btnSleep = new TacticalButton("\uD83D\uDCA4 REST");
        TacticalButton btnEat = new TacticalButton("\u2615 EAT");
        TacticalButton btnAmmo = new TacticalButton("\uD83E\uDD87 RELOAD");

        buttonPanel.add(btnVoice);
        buttonPanel.add(btnPatrol);
        buttonPanel.add(btnSleep);
        buttonPanel.add(btnEat);
        buttonPanel.add(btnAmmo);
        
        bodyPanel.add(buttonPanel);

        btnVoice.addActionListener(e -> {
            if (!isRecording) {
                // START RECORDING
                isRecording = true;
                btnVoice.setText("🛑 STOP & SEND");
                btnVoice.setForeground(new Color(231, 76, 60)); // Red
                audioRecorder.startRecording();
            } else {
                // STOP RECORDING & PROCESS
                isRecording = false;
                btnVoice.setText("⏳ THINKING...");
                btnVoice.setForeground(new Color(241, 196, 15)); // Yellow
                
                new Thread(() -> {
                    try {
                        String transcription = audioRecorder.stopRecordingAndTranscribe();
                        processUserMessage(transcription);
                    } catch (Exception ex) {
                        ex.printStackTrace();
                    } finally {
                        SwingUtilities.invokeLater(() -> {
                            btnVoice.setText("\uD83C\uDF99\uFE0F TALK");
                            btnVoice.setForeground(new Color(241, 196, 15));
                        });
                    }
                }).start();
            }
        });

        btnSleep.addActionListener(e -> triggerAction("sleep"));
        btnEat.addActionListener(e -> triggerAction("eat"));
        btnPatrol.addActionListener(e -> triggerAction("patrol"));
        btnAmmo.addActionListener(e -> triggerAction("reload"));

        updateStatsUI();

        gameLoop = new GameLoopThread(stats, this, db);
        gameLoop.start();
    }

    public void updateStatsUI() {
        statsPanel.updateStats(stats.getStamina(), stats.getBatarangAmmo(), stats.getCityThreatLevel());
    }

    public void triggerAction(String action) {
        switch (action.toLowerCase()) {
            case "patrol":
                stats.addBatarangAmmo(-10);
                stats.addCityThreatLevel(-20);
                stats.addStamina(-15);
                avatarPanel.setImage("forward.gif");
                break;
            case "reload":
                stats.addBatarangAmmo(25);
                avatarPanel.setImage("idle.gif");
                break;
            case "sleep":
                stats.addStamina(30);
                avatarPanel.setImage("sleep.gif");
                break;
            case "eat":
                stats.addStamina(15);
                avatarPanel.setImage("eat.gif");
                break;
        }
        updateStatsUI();
        db.saveStats(stats);
        
        Timer t = new Timer(3000, e -> avatarPanel.setImage("idle.gif"));
        t.setRepeats(false);
        t.start();
    }

    private void processUserMessage(String msg) {
        new SwingWorker<String, Void>() {
            @Override
            protected String doInBackground() {
                return llmClient.askBatman(msg, stats);
            }
            @Override
            protected void done() {
                try {
                    String response = get();
                    playFishAudio(response);

                    String lowerRes = response.toLowerCase();
                    if (lowerRes.contains("joker") || lowerRes.contains("angry")) {
                        avatarPanel.setImage("angry.gif");
                    } else if (lowerRes.contains("happy")) {
                        avatarPanel.setImage("happy.gif");
                    } else {
                        avatarPanel.setImage("idle.gif");
                    }
                    
                    Timer t = new Timer(4000, e -> avatarPanel.setImage("idle.gif"));
                    t.setRepeats(false);
                    t.start();
                } catch (Exception e) {}
            }
        }.execute();
    }

    private void playFishAudio(String textToSpeak) {
        System.out.println("-> [Voice Triggered]: " + textToSpeak);
        new Thread(() -> {
            try {
                java.net.URL url = java.net.URI.create("http://127.0.0.1:5000/tts").toURL();
                java.net.HttpURLConnection conn = (java.net.HttpURLConnection) url.openConnection();
                conn.setRequestMethod("POST");
                conn.setRequestProperty("Content-Type", "application/json");
                conn.setDoOutput(true);

                String escapedText = textToSpeak.replace("\\", "\\\\").replace("\"", "\\\"").replace("\n", " ");
                String jsonPayload = "{\"text\": \"" + escapedText + "\"}"; 
                
                try (java.io.OutputStream os = conn.getOutputStream()) {
                    byte[] input = jsonPayload.getBytes("utf-8");
                    os.write(input, 0, input.length);
                }
                
                // Trigger it and let python play the high quality voice
                conn.getResponseCode();
            } catch (Exception e) {
                e.printStackTrace();
            }
        }).start();
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new BatmanPet().setVisible(true));
    }

    // --- SLEEK PROFESSIONAL UI COMPONENTS ---

    class TacticalAvatarPanel extends JPanel {
        private Image gifImage;
        public TacticalAvatarPanel() {
            setBackground(new Color(25, 25, 30));
            setBorder(BorderFactory.createLineBorder(new Color(45, 45, 50), 1));
            setImage("idle.gif");
        }
        public void setImage(String path) {
            try { gifImage = new ImageIcon(path).getImage(); } catch(Exception e) {}
            repaint();
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            if (gifImage != null) {
                Graphics2D g2 = (Graphics2D) g;
                int origW = gifImage.getWidth(null);
                int origH = gifImage.getHeight(null);
                if (origW > 0 && origH > 0) {
                    // Scale the GIF up to fill 80% of the panel, maintaining aspect ratio
                    double scale = Math.min((double) getWidth() / origW, (double) getHeight() / origH) * 0.8;
                    int imgW = (int) (origW * scale);
                    int imgH = (int) (origH * scale);
                    
                    // Use BICUBIC for high-quality, smooth rendering (fixes messed up colors/jagged edges)
                    g2.setRenderingHint(RenderingHints.KEY_INTERPOLATION, RenderingHints.VALUE_INTERPOLATION_BICUBIC);
                    g2.setRenderingHint(RenderingHints.KEY_RENDERING, RenderingHints.VALUE_RENDER_QUALITY);
                    g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);
                    
                    g2.drawImage(gifImage, (getWidth()-imgW)/2, (getHeight()-imgH)/2, imgW, imgH, this);
                }
            }
        }
    }

    class TacticalStatsPanel extends JPanel {
        private int stamina=100, ammo=100, threat=0;
        public TacticalStatsPanel() {
            setBackground(new Color(25, 25, 30));
            setBorder(BorderFactory.createLineBorder(new Color(45, 45, 50), 1));
        }
        public void updateStats(int s, int a, int t) {
            stamina = s; ammo = a; threat = t;
            repaint();
        }
        @Override
        protected void paintComponent(Graphics g) {
            super.paintComponent(g);
            Graphics2D g2 = (Graphics2D) g;
            g2.setRenderingHint(RenderingHints.KEY_ANTIALIASING, RenderingHints.VALUE_ANTIALIAS_ON);

            drawBar(g2, "STAMINA", stamina, 25, 30, new Color(46, 204, 113));
            drawBar(g2, "BATARANGS", ammo, 25, 80, new Color(241, 196, 15));
            drawBar(g2, "CITY THREAT", threat, 25, 130, new Color(231, 76, 60));
        }
        
        private void drawBar(Graphics2D g2, String label, int value, int x, int y, Color color) {
            g2.setColor(new Color(200, 200, 210));
            g2.setFont(new Font("Consolas", Font.BOLD, 13));
            g2.drawString(label + " [" + value + "%]", x, y);
            
            // Background track
            g2.setColor(new Color(18, 18, 20));
            g2.fillRoundRect(x, y + 10, 280, 14, 8, 8);
            
            // Foreground fill
            g2.setColor(color);
            int width = (int) (280 * (value / 100.0));
            g2.fillRoundRect(x, y + 10, width, 14, 8, 8);
        }
    }

    class TacticalButton extends JButton {
        public TacticalButton(String text) {
            super(text);
            setFocusPainted(false);
            setBorderPainted(false);
            setContentAreaFilled(false);
            setOpaque(true);
            setBackground(new Color(40, 40, 45));
            setForeground(Color.WHITE);
            setFont(new Font("Segoe UI Emoji", Font.BOLD, 15)); 
            setCursor(new Cursor(Cursor.HAND_CURSOR));
            
            addMouseListener(new MouseAdapter() {
                public void mouseEntered(MouseEvent e) { setBackground(new Color(60, 60, 65)); }
                public void mouseExited(MouseEvent e) { setBackground(new Color(40, 40, 45)); }
            });
        }
    }
}
